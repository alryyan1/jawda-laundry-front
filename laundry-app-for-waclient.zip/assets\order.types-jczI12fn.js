const e=["pending","processing","ready_for_pickup","completed","cancelled"];export{e as o};
