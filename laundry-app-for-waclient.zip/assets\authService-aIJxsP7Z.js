import{b as a}from"./index-C2ERC1A0.js";const n=async t=>{const{data:s}=await a.post("/register",t);return s},o=async t=>{const{data:s}=await a.post("/login",t);return s};export{o as l,n as r};
