import{d0 as a}from"./index-C2ERC1A0.js";function g(r,e){return a(r,e==null?void 0:e.in).getMonth()}function u(r,e){return a(r,e==null?void 0:e.in).getFullYear()}export{g as a,u as g};
