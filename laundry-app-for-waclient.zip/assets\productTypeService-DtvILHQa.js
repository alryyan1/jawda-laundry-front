import{b8 as o}from"./index-C2ERC1A0.js";const e=async r=>{const t={},{data:a}=await o.get("/product-types",{params:t});return a.data};export{e as g};
